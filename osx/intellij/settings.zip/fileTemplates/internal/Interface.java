/*
 * Copyright ${YEAR} Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public interface ${NAME} {
}
